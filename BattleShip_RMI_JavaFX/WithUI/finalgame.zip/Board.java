public class Board {
    int boardSize = 10;
    char[][] gameBoard = new char[boardSize][boardSize];
    StringBuilder boardRepresentation;

    Board() {

    }

    void initializeBoard() {
        for (int i = 0; i < boardSize; i++) {
            for (int j = 0; j < boardSize; j++) {
                gameBoard[i][j] = '-';
            }
        }
    }

    void updateBoard(int x, int y) {

        gameBoard[x][y] = 'X';
    }

    void markShipHit(int x, int y){
        gameBoard[x][y] = 'S';
    }
    void printBoard() {
        boardRepresentation = new StringBuilder();
        boardRepresentation.append(Player.BOARD);
        System.out.print(Player.BOARD);
        System.out.println();
        boardRepresentation.append("\n");
        System.out.println();
        boardRepresentation.append("\n");
        for (int i = 0; i < boardSize; i++) {
            for (int j = 0; j < boardSize; j++) {
                System.out.print(" " + gameBoard[i][j]);
                boardRepresentation.append(" ").append(gameBoard[i][j]);
            }
            System.out.println();
            boardRepresentation.append("\n");
        }

    }

    public String toString() {
        return boardRepresentation.toString();
    }

    public static void main(String[] args) {
        Board newBoard = new Board();
        newBoard.initializeBoard();
        newBoard.printBoard();
    }
}